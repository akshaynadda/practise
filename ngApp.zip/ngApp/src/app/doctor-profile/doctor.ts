export class Doctor {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    active: boolean;
}