package com.app.pojos;

public enum UserType {
	PATIENT,ADMIN
}
