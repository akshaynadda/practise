/*
 * package com.app.pojos;
 * 
 * public enum SpecializationType {
 * Neurologist,General_Physician,Gynaecologist,Cardiologist,Orthologist,Dentist,
 * Ayurvedik,Homeopathy }
 */