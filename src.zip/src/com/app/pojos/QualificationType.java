package com.app.pojos;

public enum QualificationType {
	MBBS,MD,BDS,BHMS,BAMS,Ayurvedik,Homeopathy
}
